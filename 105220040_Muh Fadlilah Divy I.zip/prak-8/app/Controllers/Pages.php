<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'tittle' => 'Monitoring IoT'
        ];

        return view('pages/home', $data);
    }
}
