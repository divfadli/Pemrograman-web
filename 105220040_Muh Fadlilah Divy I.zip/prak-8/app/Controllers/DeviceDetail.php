<?php

namespace App\Controllers;

use App\Models\DeviceModel;

class DeviceDetail extends BaseController
{
    public function __construct()
    {
        $this->deviceModel = new DeviceModel();
    }
    public function index($slug)
    {
        $data = [
            'title' => 'Detail Device',
            'devices' => $this->deviceModel->getDevice($slug)
        ];

        return view('device/detail/index', $data);
    }

    public function detail()
    {
        $data = [
            'tittle' => 'Daftar Device IoT',
            'devices' => $this->deviceModel->findAll()
        ];

        return view('device/detail/details', $data);
    }
}
