<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Welcome to Website Monitoring IoT</h1>
            <p><b>Monitoring IoT</b> inventory is the process of discovering, evaluating, monitoring, and managing your connected devices.</p>
            <p>CLICK THE BUTTON BELOW</p>
            <a href="/device" class="btn btn-primary" role="button">Device IoT</a>
        </div>
    </div>
</div>


<?= $this->endSection(); ?>