<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <?php foreach ($devices as $d) : ?>
                        <div class="col-md-4">
                            <img src="/img/<?= $d['sampul'] ?>" class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><?= $d['device_name'] ?></h5>
                                <p class="card-text"><b>Brand: </b><?= $d['device_brand'] ?></p>
                                <p class="card-text"><b>Quantity: </b><?= $d['device_quantity'] ?></p>
                            </div>
                        </div>
                    <?php endforeach ?>
                    <a href="/device" class="btn btn-primary">Back to Home</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>